plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rexyy.watester"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rexyy.watester"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
