package com.rexyy.watester

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 18)
    private val panel = Color.rgb(22, 21, 36)
    private val purple = Color.rgb(165, 105, 255)
    private val cyan = Color.rgb(66, 220, 255)
    private val white = Color.rgb(245, 244, 255)
    private val muted = Color.rgb(170, 168, 190)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var phoneInput: EditText
    private lateinit var statusText: TextView
    private lateinit var logText: TextView
    private lateinit var testButton: Button
    private var testRunning = false
    private var testStartedAt = 0L
    private val logs = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        buildUi()
        addLog("Aplikasi siap. Pengujian berjalan lokal di aplikasi ini.")
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "REXYY"
            textSize = 30f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            letterSpacing = 0.12f
        }
        page.addView(brand)
        page.addView(text("WA TESTER  •  ANDROID LAB", 13f, purple, true).apply {
            letterSpacing = 0.08f
            setPadding(0, 0, 0, dp(18))
        })

        val hero = card()
        hero.addView(text("PERFORMANCE LAB", 18f, white, true))
        hero.addView(text("Uji performa aplikasi ini dengan aman. Semua tes berjalan lokal; tidak menyerang WhatsApp atau perangkat lain.", 14f, muted, false).apply {
            setPadding(0, dp(8), 0, dp(12))
        })
        statusText = text("STATUS: SIAP", 13f, cyan, true)
        hero.addView(statusText)
        page.addView(hero, matchWrap())

        val waCard = card()
        waCard.addView(text("01  •  WHATSAPP LAUNCHER", 16f, white, true))
        waCard.addView(text("Masukkan nomor untuk membuka chat melalui WhatsApp. Pesan tidak dikirim otomatis.", 13f, muted, false).apply {
            setPadding(0, dp(6), 0, dp(10))
        })
        phoneInput = EditText(this).apply {
            hint = "+62 812 3456 7890"
            setHintTextColor(Color.rgb(115, 112, 138))
            setTextColor(white)
            textSize = 16f
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(35, 32, 52))
        }
        waCard.addView(phoneInput, matchWrap())
        waCard.addView(actionButton("BUKA CHAT WHATSAPP", purple) { openWhatsApp() }, matchWrap())
        page.addView(waCard, matchWrap())

        val testCard = card()
        testCard.addView(text("02  •  PERFORMANCE TEST", 16f, white, true))
        testCard.addView(text("Menjalankan beban komputasi ringan dengan batas 10 detik. Hentikan kapan saja.", 13f, muted, false).apply {
            setPadding(0, dp(6), 0, dp(10))
        })
        testButton = actionButton("START PERFORMANCE TEST", cyan) { togglePerformanceTest() }
        testCard.addView(testButton, matchWrap())
        testCard.addView(actionButton("SIMULASI ERROR INTERNAL", purple) { simulateCaughtError() }, matchWrap())
        page.addView(testCard, matchWrap())

        val logsCard = card()
        logsCard.addView(text("03  •  TEST LOG", 16f, white, true))
        logText = text("Belum ada catatan.", 12f, muted, false).apply {
            setPadding(0, dp(10), 0, dp(8))
        }
        logsCard.addView(logText)
        logsCard.addView(actionButton("HAPUS RIWAYAT", Color.rgb(80, 76, 100)) {
            logs.clear()
            refreshLogs()
            addLog("Riwayat dibersihkan.")
        }, matchWrap())
        page.addView(logsCard, matchWrap())

        page.addView(text("REXYY WA TESTER • v1.0 • LOCAL TESTING ONLY", 11f, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })
    }

    private fun openWhatsApp() {
        val raw = phoneInput.text.toString().trim()
        var digits = raw.filter { it.isDigit() }
        if (digits.startsWith("0")) digits = "62" + digits.drop(1)
        if (digits.startsWith("8")) digits = "62$digits"
        if (digits.length < 10 || digits.length > 15) {
            addLog("Nomor tidak valid. Gunakan format +62xxxxxxxxxx.")
            statusText.text = "STATUS: PERIKSA NOMOR"
            return
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits"))
            startActivity(intent)
            addLog("Membuka chat WhatsApp untuk nomor yang dimasukkan.")
        } catch (e: Exception) {
            addLog("WhatsApp/chat tidak dapat dibuka: ${e.javaClass.simpleName}")
        }
    }

    private fun togglePerformanceTest() {
        if (testRunning) {
            testRunning = false
            handler.removeCallbacks(performanceTick)
            testButton.text = "START PERFORMANCE TEST"
            statusText.text = "STATUS: TES DIHENTIKAN"
            addLog("Tes performa dihentikan oleh pengguna.")
            return
        }
        testRunning = true
        testStartedAt = System.currentTimeMillis()
        testButton.text = "STOP TEST"
        statusText.text = "STATUS: TES BERJALAN"
        addLog("Tes performa dimulai (maksimum 10 detik).")
        handler.post(performanceTick)
    }

    private val performanceTick = object : Runnable {
        override fun run() {
            if (!testRunning) return
            val elapsed = System.currentTimeMillis() - testStartedAt
            // Small, bounded workload on the UI thread for a simple demo.
            var value = 0.0
            for (i in 1..12000) value += sqrt(i.toDouble())
            if (value.isNaN()) addLog("Pemeriksaan numerik selesai.")
            if (elapsed >= 10_000L) {
                testRunning = false
                testButton.text = "START PERFORMANCE TEST"
                statusText.text = "STATUS: TES SELESAI"
                addLog("Tes performa selesai dalam ${elapsed / 1000.0} detik.")
            } else {
                statusText.text = "STATUS: TES BERJALAN • ${elapsed / 1000}s"
                handler.postDelayed(this, 1000L)
            }
        }
    }

    private fun simulateCaughtError() {
        try {
            throw IllegalStateException("Contoh error simulasi internal")
        } catch (e: IllegalStateException) {
            statusText.text = "STATUS: ERROR SIMULASI TERTANGKAP"
            addLog("Simulasi berhasil: ${e.message}. Aplikasi tetap berjalan.")
        }
    }

    private fun addLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logs.add(0, "[$time] $message")
        if (logs.size > 40) logs.removeAt(logs.lastIndex)
        if (::logText.isInitialized) refreshLogs()
    }

    private fun refreshLogs() {
        logText.text = if (logs.isEmpty()) "Belum ada catatan." else logs.joinToString("\n\n")
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(14) }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun actionButton(label: String, color: Int, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setTextColor(if (color == cyan) Color.rgb(8, 15, 24) else white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        testRunning = false
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
